/*
** EPITECH PROJECT, 2021
** my_ftp
** File description:
** my.h
*/

#ifndef MY_H_
#define MY_H_

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <dirent.h>
#include <fcntl.h>
#include <errno.h>
#include <netdb.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <string.h>

enum e_mode {NO_TYPE, B, A};

typedef struct s_ftp
{
    char to_end;
    enum e_mode type;
    int mega;
    char *ip;
    int port;
} t_ftp;

typedef struct s_tab
{
    char *name;
    void (*ptr)(char *, char **, int, t_ftp *);
} t_tab;

int nbr_of_argmt(int, char **);
int high_nbr_port(int i);
int ftp_main(int i, int k);

char **str_port(char **);
t_ftp init_hand_cmd(t_ftp);
void port_fun(t_ftp *, char **, int );
void for_dele(char *, char **, int, t_ftp *);
void my_condition(int , int , t_ftp *);
void my_condition_2(t_ftp *, int , int , char **);
void for_stor(char *, char **, int, t_ftp *);
void my_condition_5(t_ftp *, char *, int *);
void my_condition_4(t_ftp *, char **, char *, int *);
void for_retr(char *, char **, int, t_ftp *);
void my_condition_6(int , DIR *, t_ftp *, struct dirent *);
void my_condition_7(t_ftp *, DIR *, struct dirent *, int );
void for_list(char *, char **, int, t_ftp *);
void my_ftp_s(char *, char **, int , t_ftp *);
void for_quit(char *, char **, int, t_ftp *);
void for_help(char *, char **, int, t_ftp *);
void for_noop(char *, char **, int, t_ftp *);
void hand_cmd(int, FILE *);
void my_pas_1(struct sockaddr_in *, int );
int my_utils_1(char *, int );
int port_handler(char *);
void for_port(char *, char **, int, t_ftp *);
void my_func(int, t_ftp *, struct sockaddr_in );
void for_pasv(char *, char **, int, t_ftp *);
int sum(char *, int *);
int my_func_d(t_ftp *, struct sockaddr_in , socklen_t , int *);
void my_init_func(struct sockaddr_in , t_ftp *, int );
char make_link(t_ftp *, int );
void fill(int, t_ftp *);
void my_other_1(char **, char *, int);
void connection(int , char *, char **);
void my_other_2(char *, int);
void my_other_3(char *, int);
void to_login(int, char *, char *, char **);
void memory_null(char *, char **);
void for_log(int, FILE *, char *);
void my_path_fun(int, char *);
void for_pwd(char *, char **, int, t_ftp *);
void for_cdup(char *, char **, int, t_ftp *);
void for_cwd(char *, char **, int, t_ftp *);
int word_len(char *, char);
char **tab_word(char *);
void make_empty(char **);
char recup(char **, char ***, FILE *);
int sock_hand(int);
int idem_ip(int);
int fun_soc(struct sockaddr_in, int, int, int);
int close_fd(int);
int mana_fun(int, int);
int is_socket(int, char *);
int make_compare(const char *, const char *);
char *allocate(const char *);
int my_str_isnum(char const *);

void init_one(t_ftp *, struct sockaddr_in);
struct sockaddr_in one_func(struct sockaddr_in, int *);
void init_for_cdup(char *, t_ftp *, char **);

#endif
