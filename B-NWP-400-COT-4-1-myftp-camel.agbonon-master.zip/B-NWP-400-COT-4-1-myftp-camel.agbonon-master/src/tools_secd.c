/*
** EPITECH PROJECT, 2021
** B-NWP-400-COT-4-1-myftp-camel.agbonon
** File description:
** tools_secd
*/

#include "../include/my.h"

int my_str_isnum(char const *str)
{
    int i = 0;

    if (str[i] == '\0')
        return (1);
    while (str[i] != '\0') {
        if (str[i] >= '0' && str[i] <= '9') {
            i = i + 1;
            if (str[i] == '\0')
                return (1);
        }
        else
            return (0);
    }
}

int nbr_of_argmt(int ac, char **av)
{
    if (ac != 3 || my_str_isnum(av[1]) == 0)
        return (-1);
    return (0);
}

int high_nbr_port(int i)
{
    if (i > 65535)
        return (84);
    return (0);
}
