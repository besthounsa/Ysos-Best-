/*
** EPITECH PROJECT, 2021
** B-NWP-400-COT-4-1-myftp-camel.agbonon
** File description:
** tools
*/

#include "../include/my.h"

void my_other_1(char **wtab, char *login, int i)
{
    (strcmp(wtab[1], "Anonymous") == 0) ? (*login = 1) : (*login = 2);
    write(i, "331 A password is required\r\n", 28);
}

void my_other_2(char *is_logged, int i)
{
    *is_logged = 1;
    write(i, "230 You're now log in !\r\n", 25);
}

void my_other_3(char *login, int i)
{
    *login = 0;
    write(i, "331 Wrong pass\r\n", 16);
}
