/*
** EPITECH PROJECT, 2021
** myftp
** File description:
** ftp
*/

#include "../include/my.h"

void for_pasv(char *oo, char **str, int i, t_ftp *my)
{
    struct sockaddr_in ftp;
    socklen_t ftp_len;

    (void)oo;
    (void)str;

    ftp_len = sizeof(ftp);
    my->mega = ftp_main(0, i);
    getsockname(my->mega, (struct sockaddr *)&ftp, &ftp_len);
    (my->mega != -1) ? my_func(i, my, ftp) : 0;
}

void for_noop(char *m, char **str, int i, t_ftp *ftp)
{
    (void)m;
    (void)str;
    (void)i;
    (void)ftp;

    write(i, "200 NOOP OKAY !\r\n", 17);

    return ;
}

void for_list(char *p, char **str, int i, t_ftp *ftp)
{
    DIR *dir;
    struct dirent *s_dir;

    (void)*p;
    (void)*str;
    (ftp->type == NO_TYPE) ? write(i, "425 No mode selected\r\n", 22)
    : my_condition_7(ftp, dir, s_dir, i);
}

void for_port(char *t, char **str, int descr, t_ftp *i)
{
    (void)t;
    (void)str;
    i->port = port_handler(str[1]);
    str = str_port(str);
    port_fun(i, str, descr);
}