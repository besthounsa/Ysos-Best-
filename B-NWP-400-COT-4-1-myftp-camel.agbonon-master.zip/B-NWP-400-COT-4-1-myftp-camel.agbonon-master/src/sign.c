/*
** EPITECH PROJECT, 2021
** myftp
** File description:
** ftp
*/

#include "../include/my.h"

void for_log(int k, FILE *s_cli, char *m)
{
    char *str, **tab, login = 0;

    for (; *m == 0; ) {
        tab = NULL;
        str = NULL;
        (recup(&str, &tab, s_cli) == -1 || make_compare(str, "quit") == 0)
        ? *m = -1 : (tab[1] != NULL && make_compare(tab[0], "user") == 0)
        ? connection(k, &login, tab)
        : (make_compare(tab[0], "pass") == 0)
        ? to_login(k, &login, m, tab) :
        write(k, "530 You're not identificated !\r\n", 32);
        memory_null(str, tab);
    }
}

void connection(int p, char *des, char **wtab)
{
    (*des  == 1) ? write(p, "530 You cannot change user\r\n", 28)
    : my_other_1(wtab, des, p);
}

void to_login(int p, char *des, char *str, char **wtab)
{
    (*des == 1 && wtab[1] == NULL) ? my_other_2(str, p)	:
    (*des == 0) ? write(p, "332 A login is needed\r\n", 23) :
    (wtab[1] != NULL || *des == 2) ? my_other_2(des, p) : 0;
}

void memory_null(char *str, char **wtab)
{
    make_empty(wtab);
    (str != NULL) ? free(str) : 0;
}