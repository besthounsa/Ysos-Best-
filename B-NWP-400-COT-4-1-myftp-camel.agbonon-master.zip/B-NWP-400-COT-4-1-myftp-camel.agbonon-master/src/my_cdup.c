/*
** EPITECH PROJECT, 2021
** B-NWP-400-COT-4-1-myftp-camel.agbonon
** File description:
** my_cdup
*/

#include "../include/my.h"

void for_dele(char *p, char **str, int i, t_ftp *d)
{
    (void)*p;
    (void)d;
    (access(str[1], F_OK) != 0) ? write(i, "550 File doesn't exist\r\n", 24)
    : (str[1] == NULL || str[2] != NULL) ?
    write(i, "501 Only one file can be remove\r\n", 33) : (unlink(str[1]) == 0)
    ? write(i, "250 A file has been removed\r\n", 29)
    : write(i, "550 Cannot remove directory\r\n", 29);
}

void for_cwd(char *p, char **str, int descr, t_ftp *ftp)
{
    (void)p;
    (void)ftp;
    (str[1] == NULL) ? write(descr, "501 No path specified\r\n", 23) :
    (chdir(str[1]) == -1) ?
    write(descr, "550 This directory don't exist\r\n", 32) :
    write(descr, "250 You've change directory successfully !\r\n", 44);
}

void for_cdup(char *p, char **str, int descr, t_ftp *ftp)
{
    (void)p;
    (void)ftp;
    (void)str;
    (chdir("..") == -1) ? write(descr, "550 You cannot move there\r\n", 27) :
    write(descr, "200 You've move to parent's directory !\r\n", 41);
}
