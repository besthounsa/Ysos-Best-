/*
** EPITECH PROJECT, 2021
** myftp
** File description:
** ftp
*/

#include "../include/my.h"

void init_one(t_ftp *detail, struct sockaddr_in ftp)
{
    ftp.sin_family = AF_INET;
    ftp.sin_port = htons(detail->port);
    ftp.sin_addr.s_addr = inet_addr(detail->ip);
}

void my_condition_5(t_ftp *detail, char *c, int *tab)
{
    write(tab[2], "150 Connexion is ready\r\n", 24);
    while ((tab[1] = read(tab[0], c, 1024)) > 0) {
        c[tab[1]] = '\0';
        write(detail->mega, c, tab[1]);
    }
    write(tab[2], "226 End of transmission\r\n", 25);
    close(tab[0]);
}

void my_condition_4(t_ftp *detail, char **let_arr, char *c, int *tab)
{
    int tab_1[] = {tab[0], tab[1], tab[2]};

    make_link(detail, tab[2]);
    ((tab[0] = open(let_arr[1], O_RDONLY)) == -1)
    ? write(tab[2], "550 This file doesn't exist\r\n", 29)
    : my_condition_5(detail, c, tab_1);
    close(detail->mega);
}

void hand_cmd(int descr, FILE *stream_client)
{
    char *str, **let_arr;
    t_ftp detail;

    detail = init_hand_cmd(detail);
    for (; detail.to_end == 0; ) {
        str = NULL;
        let_arr = NULL;
        recup(&str, &let_arr, stream_client);
        printf("%s\n", str);
        my_ftp_s(str, let_arr, descr, &detail);
        (str != NULL) ? free(str) : 0;
        make_empty(let_arr);
    }
}
