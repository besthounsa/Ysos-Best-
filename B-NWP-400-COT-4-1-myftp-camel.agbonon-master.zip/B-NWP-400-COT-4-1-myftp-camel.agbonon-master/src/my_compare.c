/*
** EPITECH PROJECT, 2021
** ftp
** File description:
** ftp
*/

#include "../include/my.h"

int make_compare(const char *s1, const char *s2)
{
    const unsigned char *str1 = (const unsigned char *) s1;
    const unsigned char *str2 = (const unsigned char *) s2;
    int i;

    if (str1 == str2)
        return 0;
    while ((i = tolower(*str1) - tolower(*str2 ++)) == 0)
        if (*str1 ++ == '\0')
            break;

    return (i);
}

int ftp_main(int i, int k)
{
    struct protoent *p;
    int fd;
    struct sockaddr_in s_ftp;

    ((p = getprotobyname("TCP")) == NULL) ? exit(84) : 0;
    ((fd = socket(AF_INET, SOCK_STREAM, p->p_proto)) == -1)
    ? exit(84) : 0;
    return (fun_soc(s_ftp, k, i, fd));
}

int mana_fun(int i, int k)
{
    (write(i, "220 Glad to see you !\r\n", 23) < 0) ? exit(-1) : 0;
    close(k);
    sock_hand(i);
    return (0);
}

char *allocate(const char *s)
{
    size_t len = strlen(s) + 1;
    void *new = malloc(len);

    if (new == NULL)
        return NULL;

    return ((char *) memcpy(new, s, len));
}