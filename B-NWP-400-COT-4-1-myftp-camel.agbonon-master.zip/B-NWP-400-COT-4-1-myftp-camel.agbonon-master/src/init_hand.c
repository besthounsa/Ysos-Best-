/*
** EPITECH PROJECT, 2021
** B-NWP-400-COT-4-1-myftp-camel.agbonon
** File description:
** init_hand
*/

#include "../include/my.h"

char make_link(t_ftp *detail, int descr)
{
    struct sockaddr_in ftp;
    socklen_t len;
    int tmp;
    struct protoent *m;

    tmp = detail->mega, len = 0;
    int array[] = {descr, tmp};
    (detail->type == B) ? exit(my_func_d(detail, ftp, len, array)) : 0;
    ((m = getprotobyname("TCP")) == NULL) ? (exit(84)) : 0;
    ((detail->mega = socket(AF_INET, SOCK_STREAM, m->p_proto)) == -1)
        ? (exit(84)) : 0;
    my_init_func(ftp, detail, descr);

    return (0);
}

void fill(int k, t_ftp *details)
{
    int j, i;
    char *str = malloc(sizeof(1028));

    for (; (j = read(details->mega, &str, 1024)) > 0; ) {
        i = -1;
        for (; ++i < j; )
            (!(str[i] == '\r' && str[i + 1] == '\n'))
            ? write(k, &str[i], 1) : 0;
    }
}

int idem_ip(int fd)
{
    struct sockaddr_in addr;
    socklen_t addr_len;

    if (fd == -1)
        return (htons(INADDR_ANY));
    addr_len = sizeof(addr);
    getsockname(fd, (struct sockaddr *)&addr, &addr_len);
    return (addr.sin_addr.s_addr);
}

t_ftp init_hand_cmd(t_ftp detail)
{
    detail.to_end = 0;
    detail.type = NO_TYPE;
    detail.mega = -1;

    return (detail);
}