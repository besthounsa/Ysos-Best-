/*
** EPITECH PROJECT, 2021
** B-NWP-400-COT-4-1-myftp-camel.agbonon
** File description:
** util_arr
*/

#include "../include/my.h"

int word_len(char *str, char c)
{
    int i = 0, j = 1;

    for ( ; str[i] != '\0'; i++)
        (str[i] == c && str[i + 1] != c && str[i + 1] != '\0') ? j++ : 0;

    return (j);
}

char recup(char **str, char ***tab, FILE *p)
{
    long unsigned int i = 0;

    (getline(str, &i, p) == -1) ? exit(84) : 0;
    ((*str)[strlen(*str) - 2] == '\r') ? ((*str)[strlen(*str) - 2] = '\0') : 0;
    *tab = tab_word(*str);
    return (0);
}
