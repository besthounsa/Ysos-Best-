/*
** EPITECH PROJECT, 2021
** my_ftp
** File description:
** ftp
*/

#include "../include/my.h"

void for_retr(char *p, char **str, int descr, t_ftp *detail)
{
    int k, tmp;
    char *to_read_ = malloc(sizeof(1024));
    int tab[] = {k, tmp, descr};
    (void)*p;

    (detail->type == NO_TYPE) ? write(descr, "425 No mode selected\r\n", 22)
    : my_condition_4(detail, str, to_read_, tab);
}

void for_quit(char *p, char **str, int i, t_ftp *ftp)
{
    (void)p;
    (void)str;
    ftp->to_end = 1;
    write(i, "221 Thanks you for coming, see you soon !\r\n", 43);
}

void for_pwd(char *oo, char **str, int j, t_ftp *ftp)
{
    (void)oo;
    (void)str;
    (void)ftp;
    my_path_fun(j, get_current_dir_name());
}

void for_stor(char *m, char **let_arr, int i, t_ftp *str)
{
    int k;

    (void)*m;
    (void)*let_arr;
    (str->type == NO_TYPE) ? write(i, "425 No mode selected\r\n", 22) :
    my_condition_2(str, k, i, let_arr);
}