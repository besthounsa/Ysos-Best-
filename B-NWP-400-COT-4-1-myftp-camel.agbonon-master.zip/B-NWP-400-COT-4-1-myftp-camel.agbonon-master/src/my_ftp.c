/*
** EPITECH PROJECT, 2021
** B-NWP-400-COT-4-1-myftp-camel.agbonon
** File description:
** my_ftp
*/

#include "../include/my.h"

void for_help(char *k, char **str, int i, t_ftp *y)
{
    (void)k;
    (void)y;
    (make_compare(str[0], "HELP") == 0)
    ? write(i, "214 All basic ftp's command\r\n", 29) : 0;
}

int close_fd(int i)
{
    close(i);
    return (-1);
}

int main(int ac, char **av)
{
    int k;

    if (nbr_of_argmt(ac, av) == -1)
        exit(84);
    if (high_nbr_port(atoi(av[1])) == 84)
        exit(84);
    if ((k = ftp_main(atoi(av[1]), -1)) == -1)
        exit(84);
    is_socket(k, av[2]);
    close(k);

    return (0);
}
