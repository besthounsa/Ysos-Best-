/*
** EPITECH PROJECT, 2021
** myftp
** File description:
** ftp
*/

#include "../include/my.h"

t_tab f_tab[] = {
    { "NOOP", &for_noop}, { "HELP", &for_help},
    { "QUIT", &for_quit}, { "CWD", &for_cwd},
    { "PWD", &for_pwd}, { "CDUP", &for_cdup},
    { "PASV", &for_pasv}, { "PORT", &for_port},
    { "LIST", &for_list}, { "RETR", &for_retr},
    { "STOR", &for_stor}, { "DELE", &for_dele},
    { "END", NULL },
};

void my_ftp_s(char *str, char **let_arr, int descr, t_ftp *details)
{
    int p = 0;

    for (; strcmp(f_tab[p].name, "END") != 0
    && make_compare(f_tab[p].name, let_arr[0]) != 0 ;)
        p++;
    (strcmp(f_tab[p].name, "END") == 0) ?
    write(descr, "500 Unknown command\r\n", 21) :
    f_tab[p].ptr(str, let_arr, descr, details);
}

void my_condition_6(int i, DIR *dir, t_ftp *detail, struct dirent *s_dir)
{
    write(i, "150 Here come the directory listing\r\n", 37);
    for (; (s_dir = readdir(dir)) != NULL; ) {
        write(detail->mega, s_dir->d_name, strlen(s_dir->d_name));
        write(detail->mega, "\n", 1);
    }
    write(i, "226 End of transmission\r\n", 25);
    closedir(dir);
}

void my_condition_7(t_ftp *detail, DIR *dir, struct dirent *s_dir, int k)
{
    make_link(detail, k);
    ((dir = opendir(get_current_dir_name())) == NULL) ?
    write(k, "450 Error while listing files\r\n", 31)
    : my_condition_6(k, dir, detail, s_dir);
    close(detail->mega);
}