/*
** EPITECH PROJECT, 2021
** B-NWP-400-COT-4-1-myftp-camel.agbonon
** File description:
** my_func
*/

#include "../include/my.h"

void my_condition(int j, int k, t_ftp *detail)
{
    write(k, "150 Connexion is ready\r\n", 24);
    fill(j, detail);
    write(k, "226 End of transmission\r\n", 25);
    close(j);
}

void my_condition_2(t_ftp *detail, int i, int j, char **let_arr)
{
    (void)*let_arr;
    make_link(detail, j);
    (i = open(let_arr[1], O_WRONLY | O_CREAT, S_IRUSR | S_IWUSR
    | S_IRGRP | S_IWGRP | S_IROTH) == -1)
    ? write(j, "550 can't create file\r\n", 23)
    : my_condition(i, j, detail);
    close(detail->mega);
}

int my_func_d(t_ftp *detail, struct sockaddr_in ftp, socklen_t len, int *array)
{
    ((detail->mega = accept(array[1], (struct sockaddr *)&ftp, &len))  == -1)
        ? write(array[0], "426 An error occured while accepting\r\n", 38) : 0;
    close(array[1]);

    return (0);
}

void my_init_func(struct sockaddr_in ftp, t_ftp *detail, int i)
{
    init_one(detail, ftp);
    (connect(detail->mega, (struct sockaddr *)&ftp, sizeof(ftp)) == -1) ?
    write(i, "426 An error occured while connecting\r\n", 39) : 0;
}
