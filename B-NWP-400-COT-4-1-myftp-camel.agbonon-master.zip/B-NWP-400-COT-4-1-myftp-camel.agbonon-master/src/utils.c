/*
** EPITECH PROJECT, 2021
** myftp
** File description:
** ftp
*/

#include "../include/my.h"

int my_utils_1(char *bar, int n)
{
    int i = n, r = 0, k = 1;

    for ( ; bar[i] != ','; i--) {
        r += (bar[i] - '0') * k;
        k *= 10;
    }
    return (r);
}

int sum(char *str, int *s)
{
    int a = my_utils_1(str, s[1] + s[2]);
    int b = my_utils_1(str, strlen(str) - 1);
    int c = (a * 256 + b);

    return (c);
}

void port_fun(t_ftp *detail, char **let_arr, int descr)
{
    detail->ip = allocate(let_arr[1]);
    detail->type = A;
    write(descr, "200 Active mode activated !\r\n", 29);
}

void my_func(int i, t_ftp *detail, struct sockaddr_in a)
{
    detail->type = B;
    my_pas_1(&a, i);
}