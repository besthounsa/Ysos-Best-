/*
** EPITECH PROJECT, 2021
** myftp
** File description:
** ftp
*/

#include "../include/my.h"

char **tab_word(char *str)
{
    int j = -1, t = word_len(str, ' '), s, m = 0;
    char **tab;

    ((tab = malloc(sizeof(char *) * (1 + t))) == NULL) ? exit(0) : 0;
    for ( ; ++j < t; ) {
        s = 0;
        for ( ; str[m + s] != '\0' && str[m + s]
        != ' ' && str[m + s] != '\n'; s++);
        tab[j] = strndup(str + m, s);
        tab[j][s] = '\0';
        m = m + s;
        for ( ; str[++m] == ' '; );
    }
    tab[j] = NULL;
    return (tab);
}

void make_empty(char **str)
{
    (str == NULL) ? exit(0) : 0;
    for (int i = 0; str[i] != NULL; free(str[i++]));
    free(str);
}

char **str_port(char **str)
{
    int a = 0, b = 0;

    for ( ; str[1][a] != '\0' && b < 4; a++) {
        if (str[1][a] == ',') {
            b++;
            str[1][a] = '.';
        }
    }
    str[1][a - 1] = '\0';
    return (str);
}