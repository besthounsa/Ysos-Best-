/*
** EPITECH PROJECT, 2021
** myftp
** File description:
** ftp
*/

#include "../include/my.h"

void my_pas_1(struct sockaddr_in *ftp, int descr)
{
    char *ip = inet_ntoa(ftp->sin_addr);
    int a = (ntohs(ftp->sin_port) / 256);
    int b = (ntohs(ftp->sin_port) % 256), inc = 0;

    write(descr, "227 Passiv mode activated (", 27);
    for (; ip[inc] != '\0'; inc++)
    (ip[inc] == '.') ? write(descr, ",", 1) :
        write(descr, &(ip[inc]), 1);
    dprintf(descr, ",%d,%d).\r\n", a, b);
}

int port_handler(char *str)
{
    int a = 0, b = 0;

    for (; b < 4 && str[a] != '\0'; )
        (str[a++] == ',') ? b++ : 0;
    b = 0;
    for (; str[a + b + 1] != ',' && str[a] != '\0'; b++);
    int tab[] = {a, b};

    return (sum(str, tab));
}

void my_path_fun(int i, char *str)
{
    write(i, "257 \"", 6);
    write(i, str, strlen(str));
    write(i, "\"\r\n", 3);
    (str != NULL) ? free(str) : 0;
}
