/*
** EPITECH PROJECT, 2021
** myftp
** File description:
** ftp
*/

#include "../include/my.h"

int sock_hand(int j)
{
    FILE *str = fdopen(j, "r");
    char dest = 0;

    for_log(j, str, &dest);
    (dest == -1) ? write(j, "221 Thanks you for coming, see you soon !\r\n", 43)
    : hand_cmd(j, str);
    close(j);
    fclose(str);
    return (0);
}

struct sockaddr_in one_func(struct sockaddr_in a, int *tab)
{
    a.sin_family = AF_INET;
    a.sin_port = htons(tab[1]);
    a.sin_addr.s_addr = idem_ip(tab[0]);

    return (a);
}

int fun_soc(struct sockaddr_in s_ftp, int k, int m, int l)
{
    int tab[] = {k, m};

    s_ftp = one_func(s_ftp, tab);
    (bind(l, (const struct sockaddr *)&s_ftp, sizeof(s_ftp)) == -1)
    ? exit(close_fd(l)) : 0;
    (listen(l, 42) == -1) ? (close_fd(l)) : 0;

    return (l);
}

int is_socket(int fd, char *str)
{
    socklen_t l;
    struct sockaddr_in ftp;
    int i, k;

    (chdir(str) == -1) ? exit(84) : 0;
    for (; 1; ) {
        l = sizeof(struct sockaddr_in);
        ((k = accept(fd,
        (struct sockaddr *)&ftp, &l)) == -1) ? exit(84) : 0;
        i = fork();
        (i == 0) ? exit(mana_fun(k, fd)) : 0;
        close(k);
    }
    return (0);
}
